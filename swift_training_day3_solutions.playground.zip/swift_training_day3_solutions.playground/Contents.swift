
import Swift
import Foundation

//3.0
//You have array of items and you what to print ony the strings that contain the string swift. Use the String contains method (it available from iOS 8.0+)

let swifts : [Any] = ["Suzuki Swift", 42, "Taylor Swift", "Maruti Swift", "someValue"]

//let wordsOfStrings = swifts.flatMap { $0 as? String }
//
//var arrayOfStrings : [String] = []
//
//for message in wordsOfStrings {
//
//    if message.contains("Swift"){
//        arrayOfStrings.append(message)
//        //print(message)
//    }
//}
//
//print(wordsOfStrings)
//print(arrayOfStrings)


//3.1 grading
//You need to write a function that takes an array of exams grades scores with value from 0 to 100 return the grade character for it (A - F). less or equal to 60 is F and then it uses the next character for each 10 points. Use pattern matching with ranges, the array will contain the grades as Ints or Strings and will contain nil values(you should count them as zero)


let grades : [Any?] = [10, 55, 80, nil, "90", 100, 66, "42", 78, 89]

//let gradesWithoutOptionals:[Any] = grades.map{ $0 ?? 0 }
//
//var finalGrades : [Any] = []
//func gradeResults(_ array:Array<Any>)->Array<Any> {
//
//    for grade in gradesWithoutOptionals{
//
//        if let grdInt = grade as? Int {
//
//            if grdInt == 100 {
//                finalGrades.append("A")
//            }
//            if ( grdInt >= 90 && grdInt < 100)  {
//                finalGrades.append("B")
//            }
//            if ( grdInt >= 80 && grdInt < 90) {
//                finalGrades.append("C")
//            }
//
//            if ( grdInt > 70 && grdInt < 80) {
//                finalGrades.append("D")
//            }
//
//            if (grdInt > 60 && grdInt < 70) {
//                finalGrades.append("E")
//            }
//
//            if grdInt <= 60 {
//                finalGrades.append("F")
//            }
//
//        }
//
//        if let grdString = grade as? String {
//
//
//            if grdString == "100" {
//                finalGrades.append("A")
//            }
//            if ( grdString >= "90" && grdString < "100" ) {
//                finalGrades.append("B")
//            }
//            if ( grdString >= "80" && grdString < "90") {
//                finalGrades.append("C")
//            }
//
//            if ( grdString >= "70" && grdString < "80") {
//                finalGrades.append("D")
//            }
//
//            if ( grdString > "60" && grdString < "70") {
//                finalGrades.append("E")
//            }
//
//            if grdString <= "60" {
//                finalGrades.append("F")
//            }
//
//        }
//    }
//
//
//    return finalGrades
//}
//
//
//let fgr = gradeResults(finalGrades)
//print(gradesWithoutOptionals)
//print(fgr)



//-------------------------------------

//End of 3.0

//-------------------------------------







//3.1 Legacy API
//Create a legacyLoginAPI function that takes a username/password and returns one of the following
//For username 'newUser'
//a User object with 3 variables first,last name,last password change date
//For username 'oldUser'
//a UserLegacy object with 2 variables first and last name,last password change date
//For any other username
//a Error object with a string error description


//protocol ParentClass {
//    var firstName: String {set get}
//    var lastName: String {set get}
//    var lastPassword: String {set get}
//    var changeDate : Date {set get}
//
//    func printValues()->Void
//}
//
//
//extension ParentClass{
//
//    func printValues() -> Void {
//        print("\(firstName) \(lastName) \(lastPassword) \(changeDate)")
//    }
//}


//enum UsernameError: Error {
//    case wrong
//}
//
//class User: ParentClass {
//
//
//
//    internal var firstName: String
//    internal var lastName: String
//    internal var lastPassword: String
//    internal var changeDate : Date
//
//    init(_ firstName:String,_ lastName:String,_ lastPassword: String,_ changedate: Date){
//
//        self.firstName = firstName
//        self.lastName = lastName
//        self.lastPassword = lastPassword
//        self.changeDate = changedate
//    }
//
//    func returnDates()-> Any {
//        var dateNow = Date.now
//        return dateNow
//    }
//
//
//
//}
//
//
//class UserLegacy: ParentClass{
//
//    internal var firstName: String
//    internal var lastName: String
//    internal var lastPassword: String
//    internal var changeDate : Date
//
//    init(_ firstName:String,_ lastName:String,_ lastPassword: String,_ changedate: Date){
//
//        self.firstName = firstName
//        self.lastName = lastName
//        self.lastPassword = lastPassword
//        self.changeDate = changedate
//    }
//
//}




//let user = User("newUser", "Kefalas", "1234rfg", Date.now)
//let userLegacy = UserLegacy("oldUser", "Konstantinidis", "1235YHT", Date.now)
//
//
//func legacyLoginAPI(_ usr:String,_ ps:String) throws ->ParentClass{
//
//    if usr == "newUser"{
//        return user
//    } else if usr == "oldUser" {
//        return userLegacy
//    } else {
//        throw UsernameError.wrong
//
//    }
//
//}

//do {
//    let result = try legacyLoginAPI("oldUser","12345")
//    print(result.printValues())
//} catch {
//    print("There was an error.")
//}




//-------------------------------------

//End of 3.1

//-------------------------------------







//3.2 Legacy API Cont.
//Write code that handles the legacyLoginAPI reponse with the following logic:
//If it returns Error print it.
//If it returns A user that has not change it's password for 6 months print "Please change your password"
//Else print "Wellcome <first Name last name>"

//
//
//protocol ParentClass {
//    var firstName: String {set get}
//    var lastName: String {set get}
//    var lastPassword: String {set get}
//    var changeDate : Date {set get}
//
//    func printValues()->Void
//}
//
//
//extension ParentClass{
//
//    func printValues() -> Void {
//        print("Welcome \(firstName) \(lastName)")
//    }
//
//
//    func ComparePasswords()->Bool{
//        var currentDate = Date.now
//        var dateComponent = DateComponents()
//        dateComponent.month = 6
//        let futureDate = Calendar.current.date(byAdding: dateComponent, to: self.changeDate)
//
//
//        if currentDate < futureDate! {
//            return true
//        }
//        return false
//
//    }
//
//    func printPasswordMessages() -> String {
//        return "Change your password"
//    }
//}
//
//
//
//enum UsernameErrorNew: Error {
//    case wrong
//}
//
//
//
//class UserNew:ParentClass{
//
//    internal var firstName: String
//    internal var lastName: String
//    internal var lastPassword: String
//    internal var changeDate : Date
//
//    init(_ firstName:String,_ lastName:String,_ lastPassword: String,_ changedate: Date){
//
//        self.firstName = firstName
//        self.lastName = lastName
//        self.lastPassword = lastPassword
//        self.changeDate = changedate
//    }
//
//    func toString()->String{
//
//        return "\(self.firstName) \(self.lastName) \(self.lastPassword) \(self.changeDate)"
//    }
//
//    func returnDateNow()-> Date {
//        self.changeDate = Date.now
//        return self.changeDate
//    }
//
//
//
//
//}
//
//
//class UserLegasyNew:ParentClass{
//
//    internal var firstName: String
//    internal var lastName: String
//    internal var lastPassword: String
//    internal var changeDate : Date
//
//    init(_ firstName:String,_ lastName:String,_ lastPassword: String,_ changedate: Date){
//
//        self.firstName = firstName
//        self.lastName = lastName
//        self.lastPassword = lastPassword
//        self.changeDate = changedate
//    }
//
//    func toString()->String{
//
//        return "\(self.firstName) \(self.lastName) \(self.lastPassword) \(self.changeDate)"
//    }
//
//
//    func returnDateNow()-> Date {
//        self.changeDate = Date.now
//        return self.changeDate
//    }
//
//}
//
//let userNew = UserNew("newUser", "Kefalas", "1234rfg", Date.now)
//let userLegasyNew = UserLegasyNew("oldUser", "Konstantinidis", "1235YHT", Date.now)
//
//
//func legacyLoginAPINew(_ usr:String,_ ps:String) throws ->ParentClass{
//
//    if usr == "newUser"{
//
//            let ifPasswordIsExpiredUserNew = userNew.ComparePasswords()
//
//            if ifPasswordIsExpiredUserNew{
//                print(userNew.printValues())
//                return userNew
//            }
//
//            print("You have to change your password")
//
//    }else if usr == "oldUser" {
//
//            let ifPasswordIsExpiredUserLegacyNew = userLegasyNew.ComparePasswords()
//
//            if ifPasswordIsExpiredUserLegacyNew{
//                print(userLegasyNew.printValues())
//                return userLegasyNew
//            }
//
//                print("You have to change your password")
//
//        }
//
//        throw UsernameErrorNew.wrong
//
//
//}
//
//
//do {
//    let resultNew = try legacyLoginAPINew("oldUser","12345")
//}catch {
//    print("There was an error.")
//}




//-------------------------------------

//End of 3.2

//-------------------------------------




//3.3 The calculator
//Write a Class with name Calculator that parses a String with a simple arithmetic operation(+ and *) and calculates the result e.g. "1+4", all the operands will be integers
//The class should have a method that registers a closure that performs an operation for an operand("+","*" etc.). All registered closures take two integers and return an other.
//If the operation is already registed it will replace it and print an warning message. It should check that the operand is not empty.
//The class should have a method with name calculate that takes a string and returns the result, if no valid operation is found it should print a relevant method.

//
//class Calculator {
//
//    private(set) var a :Int
//    private(set) var b :Int
//
//    init(_ a:Int,_ b:Int){
//        self.a = a
//        self.b = b
//    }
//
//
//    var operationPlus = {(_ a:Int,_ b:Int)->Int in
//        return a + b
//    }
//
//    var operationMulti = {(_ a:Int,_ b:Int)->Int in
//        return a * b
//    }
//
//    func calculate(_ operation:String)->Any{
//
//        if operation.isEmpty{
//            return "The operation value is empty. Place a value from + or *"
//        }
//
//        if operation == "+"{
//            var number = operationPlus(a,b)
//            return number
//        }
//
//        if operation == "*"{
//            var number = operationMulti(a,b)
//            return number
//        }
//
//        return "Please place an operator between + or *"
//    }
//
//}
//
//let calculator = Calculator(1,2)
//print(calculator.calculate("+"))
//




//-------------------------------------

//End of 3.3

//-------------------------------------





//3.4 Points & Rectangles
//Create a type that for a Point coordinate, when create a type that for a Rectangle (use the Point)
//Add a pair of methods(mutating and non-mutating) in the Rectangle that will translate(e.g. move) a Rectangle from it's origin by an offset Point(x,y)
//Add a pair of methods(mutating and non-mutating that will check if two Rectangles overlap
//Add a method that will return the distance of a Point from the Axis centre 0,0
//Add a method that will return the distance of a Point from an other Point


//
//struct Point {
//
//    private(set) var x = 0.0
//    private(set) var y = 0.0
//
//    init(_ x:Double,_ y:Double){
//        self.x = x
//        self.y = y
//    }
//
//    mutating func moveTheRectangle(_ deltaX: Double,_ deltaY: Double) {
//
//        self.x += deltaX
//        self.y += deltaY
//
//        }
//
//    mutating func checkTheDxMove(_ deltaX: Double)->Double{
//
//        let dx = deltaX - self.x
//        return dx
//    }
//
//
//    mutating func checkTheDyMove(_ deltaY: Double)->Double{
//
//        let dy = deltaY - self.y
//        return dy
//    }
//
//    mutating func checkDistanceIfOverlappedByDx(_ deltaX1:Double,_ deltaX2:Double)->Bool{
//        if deltaX2<deltaX1 {
//            return true
//        }
//
//        return false
//    }
//
//
//    mutating func checkDistanceIfOverlappedByDy(_ deltaY1:Double,_ deltaY2:Double)->Bool{
//        if deltaY2 < deltaY1 {
//            return true
//        }
//
//        return false
//    }
//
//    mutating func displayTheDistanceFromAxis()->Double{
//
//        let dist = sqrt((self.x * self.x) + (self.y * self.y))
//        return dist
//    }
//
//    mutating func displayTheDistanceBetweenTwoPoints(_ x1:Double,_ x2:Double,_ y1:Double,_ y2:Double)->Double{
//
//        let distanceBetweenTwoPoints = sqrt(((x1-x2)*(x1-x2)) + ((y1-y2)*(y1-y2)))
//
//        return distanceBetweenTwoPoints
//    }
//
//}



//-------------------------------------

//End of 3.4

//-------------------------------------





//3.5 Phone and battery
//Create a type to represent a Phone, it should have a name, a batteryCharge and a display resolution as properties.
//You can use the phone for 6 activities (Call,Video,Photo,GPS,Screen, Charge) each reduces the charge at specific rate per minute (0.5, 3.5, 1.5, 2.5, 2.0, -5.5)
//Create a method that will peform an activity for x minutes. This method will print "consumed <X> battery for <Activity name>" if there is enough battery, then is should reduce the remaining battery charge
//if not it will print not enough energy for <x> minutes of <Activity>.



//
//
//enum BatteryReduce:Double {
//    case Call = 0.5
//    case Video = 3.5
//    case Photo = 1.5
//    case GPS = 2.5
//    case Screen = 2.0
//    case Charge = -5.5
//}
//
//
//class Phone {
//
//    private(set) var name: String
//    private(set) var batteryCharge : Double
//    private(set) var displayResolution: String
//
//
//    init(_ name:String,_ batteryCharge:Double,_ displayResolution:String){
//
//        self.name = name
//        self.batteryCharge = batteryCharge
//        self.displayResolution = displayResolution
//    }
//
//
//    func printActivity (_ min:Double,batteryReduce:BatteryReduce)->Void{
//
//
//
//                var totalEnergyConsumption : Double
//                switch batteryReduce{
//
//                case .Call :
//                    totalEnergyConsumption = min * 0.5
//                    if self.batteryCharge > totalEnergyConsumption{
//                        self.batteryCharge = self.batteryCharge - totalEnergyConsumption
//                        print("Consumed \(self.batteryCharge) for \(min) minutes for the activity Call")
//                    }else{
//                        print("Not enough battery")
//
//                    }
//
//                case .Video :
//                    totalEnergyConsumption = min * 3.5
//                    if self.batteryCharge > totalEnergyConsumption{
//                        self.batteryCharge = self.batteryCharge - totalEnergyConsumption
//                        print("Consumed \(self.batteryCharge) for \(min) minutes for the activity Video")
//                    }else{
//                        print("Not enough battery")
//
//                    }
//
//
//                case .Photo :
//                    totalEnergyConsumption = min * 1.5
//                    if self.batteryCharge > totalEnergyConsumption{
//                        self.batteryCharge = self.batteryCharge - totalEnergyConsumption
//                        print("Consumed \(self.batteryCharge) for \(min) minutes for the activity Photo")
//                    }else{
//                        print("Not enough battery")
//
//                    }
//
//                case .GPS :
//                    totalEnergyConsumption = min * 2.5
//                    if self.batteryCharge > totalEnergyConsumption{
//                        self.batteryCharge = self.batteryCharge - totalEnergyConsumption
//                        print("Consumed \(self.batteryCharge) for \(min) minutes for the activity GPS")
//                    }else{
//                        print("Not enough battery")
//
//                    }
//
//                case .Screen :
//                    totalEnergyConsumption = min * 2.0
//                    if self.batteryCharge > totalEnergyConsumption{
//                        self.batteryCharge = self.batteryCharge - totalEnergyConsumption
//                        print("Consumed \(self.batteryCharge) for \(min) minutes for the activity Screen")
//                    }else{
//                        print("Not enough battery")
//
//                    }
//                default :
//
//                    totalEnergyConsumption = min * (5.5)
//                    if self.batteryCharge > totalEnergyConsumption{
//                        self.batteryCharge = self.batteryCharge - totalEnergyConsumption
//                        print("Consumed \(self.batteryCharge) for \(min) minutes for the activity Charge")
//                    }else{
//                        print("Not enough battery")
//
//                    }
//
//                }
//
//
//    }
//
//
//}
//
//
//let phone = Phone("Iphone6",75.0,"fullyDisplay")
//phone.printActivity(5, batteryReduce: .Charge)


//-------------------------------------

//End of 3.5

//-------------------------------------





//3.6 Poker Game
//Create a Player Object that has a name, and an array of Cards (from the 2.12 exercise Deck of cards)
//Create a PokerEngine Object that will have
//a init method that adds an array of Players
//a method deal that give 5 random cards to each player
//The player should print the each card's name when it is given, use property observers


//protocol CardsCreation{
//    func cardsCreation()->[Card]
//}
//
//extension CardsCreation {
//    func cardsCreation()->[Card]{
//        var cards = [Card]()
//
//        for i in 1...13{
//            for j in 1...4{
//                var card = (Rank(rawValue: i)!,Suite(rawValue: j)!)
//                cards.append(card)
//
//            }
//        }
//        return cards
//    }
//
//
//    func deal()->[Card]{
//        var newCards : [Card] = cardsCreation()
//        var randomCards: [Card] = []
//
//        for _ in 0..<5 {
//            if let randomCard = newCards.randomElement(){
//                randomCards.append(randomCard)
//            }
//        }
//        return randomCards
//    }
//}
//
//enum Rank: Int {
//    case Ace = 1
//    case Two = 2
//    case Three = 3
//    case Four = 4
//    case Five = 5
//    case Six = 6
//    case Seven = 7
//    case Eight = 8
//    case Nine = 9
//    case Ten = 10
//    case Jack = 11
//    case Queen = 12
//    case King = 13
//
//
//}
//
//
//enum Suite : Int {
//case diamonds = 1
//case hearts = 2
//case spades = 3
//case clubs = 4
//
//}
//
//
//
//
//class Player: CardsCreation {
//
//    private(set) var fullName:String
//    private(set) var cards : [Card]
//
//    init(_ fullname: String,_ cards:[Card]){
//        self.fullName = fullname
//        self.cards = cards
//    }
//
//    func toString(){
//        for card in self.cards{
//            print(" The name of the player is \(self.fullName), and the card is \(card.0), \(card.1)")
//        }
//        print("\n")
//    }
//
//}
//
//
//class PokerEngine: CardsCreation {
//
//    private(set) var players : [Player]
//
//    init(_ players:[Player]){
//
//        self.players = players
//    }
//
//}
//
//typealias Card = (Rank, Suite)
//
//var cards1:Array<Card> = []
//var cards2:Array<Card> = []
//var cards3:Array<Card> = []
//var cards4:Array<Card> = []
//var cards5:Array<Card> = []
//var players:Array<Player> = []
//
//
//cards1 = player1.deal()
//cards2 = player2.deal()
//cards3 = player3.deal()
//cards4 = player4.deal()
//cards5 = player5.deal()
//
//
//let player1 = Player("Kostas Kefalas",cards1)
//let player2 = Player("Giannis Palaios",cards2)
//let player3 = Player("Thanasis Bimis",cards3)
//let player4 = Player("Leuteris Kostakis",cards4)
//let player5 = Player("Xristos Koninis",cards5)
//
//
//players.append(player1)
//players.append(player2)
//players.append(player3)
//players.append(player4)
//players.append(player5)
//
//
//var pokerEngine = PokerEngine(players)
//
//player1.toString()
//player2.toString()
//player3.toString()
//player4.toString()
//player5.toString()



//-------------------------------------

//End of 3.6

//-------------------------------------
