import UIKit


//extension String {
//
//    var length: Int {
//        return count
//    }
//
//    subscript (i: Int) -> String {
//        return self[i ..< i + 1]
//    }
//
//    func substring(fromIndex: Int) -> String {
//        return self[min(fromIndex, length) ..< length]
//    }
//
//    func substring(toIndex: Int) -> String {
//        return self[0 ..< max(0, toIndex)]
//    }
//
//    subscript (r: Range<Int>) -> String {
//        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
//                                            upper: min(length, max(0, r.upperBound))))
//        let start = index(startIndex, offsetBy: range.lowerBound)
//        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
//        return String(self[start ..< end])
//    }
//}

//Exercise 2.1

//func printArray(_ num:Int)->Array<Int>{
//
//    var arrayOfNums:[Int] = []
//
//    if num <= 0 {
//        return arrayOfNums
//    }
//
//        for i in 1...num {
//            arrayOfNums.append(i)
//        }
//    return arrayOfNums
//
//}
//
//let numbers = printArray(2)
//print(numbers)


//Exercise 2.2

//func repeatPrint(_ msg:String, _ count:Int){
//
//    for _ in 1...count{
//        print(msg)
//    }
//    print("\n")
//}
//
//repeatPrint("Hello iOS academy", 5)
//repeatPrint("Hello AFSE", 5)

//Exercise 2.3

//func parseDigit(_ char:String)->Int?{
//
//    let len = char.count
//
//    if len>1 {
//        return nil
//
//    }
//
//    if char == "" {return nil}
//
//    if let num = Int(char){
//        return num
//    }
//    return -1
//}
//
//
//
//
//if let characterToString = parseDigit("6") {
//    print("The character parsed to Digit is \(characterToString)")
//}


//Exercise 2.4

//func splitName(_ name:String) -> (firstName: Substring, lastName: Substring) {
//
//   let splittedName = name.split(separator: " ")
//   let name1 = splittedName[0]
//   let name2 = splittedName[1]
//
//  return  (firstName:name1 , lastName: name2)
//}
//
//let TheNorthKing = splitName("John Snow")
//print(TheNorthKing)



//Exercise 2.5


//func verify(_ msg:String)-> Bool{
//
//    var countChar_1 = 0
//    var countChar_2 = 0
//
//    for char in msg{
//        if "(" == char {countChar_1 += 1}
//        if ")" == char {countChar_2 += 1}
//
//    }
//
//    if countChar_1 == countChar_2 {return true}
//    return false
//}
//
//print(verify("(He(l)l((o)"))

//-------------------------------------------------------

//Some Comments for myself


//// create a string
//let info = "Educative is the best!"
//
//// use forEach function
//// and print each character
//info.forEach{
//    // print each character
//    print($0)
//}

//-------------------------------------------------------

//Exercise 2.6

//var arrayNums :[Int] = []
//
//
//func push(_ num:Int, _ arrayOfNums: inout [Int]){
//    arrayOfNums.append(num)
//}
//
//func pop(_ arrayOfNums: inout [Int])-> Int?{
//
//    if arrayOfNums.isEmpty == true {return nil}
//
//    let firstItem = arrayOfNums.removeFirst()
//
//    return firstItem
//
//}
//
//push(4,&arrayNums)
//print(arrayNums)
//let itemFirstOfArray = pop(&arrayNums)
//print(arrayNums)

//Exercise 2.7

//var method = {
//
//    print("This is a message")
//}
//
//func repeatKTimes(_ K:Int,action:()->Void){
//
//    for _ in 0..<K{
//        action()
//    }
//}
//
//repeatKTimes(5,action:method)

//Exercise 2.8


//var arrayOfIntNumbers :[Int] = [1,2,3,4,5,6]
//
//let doubleFromInt = { (_ num:Int) -> Double in
//
//    var doubleNum = Double(num)
//    return doubleNum
//}
//
//
//
//let doubleTheNumber = { (_ num:Int) -> Int in
//
//    var doubleNumber = num*num
//    return doubleNumber
//}
//
//func makeDoublefromInt(_ iterations:Int,action:(_ number:Int)->Double)->Array<Double>{
//
//    var arrayofdoublesResult : [Double] = []
//
//    for number in arrayOfIntNumbers{
//        let doubleNum = action(number)
//        arrayofdoublesResult.append(doubleNum)
//    }
//
//    return arrayofdoublesResult
//}
//
//
//func makeDoubleNumber(_ iterations:Int,action:(_ number:Int)->Int) -> Array<Int>{
//
//   var arrayOfDoubleNumbers : [Int] = []
//    for number in arrayOfIntNumbers{
//        let dNum = action(number)
//        arrayOfDoubleNumbers.append(dNum)
//    }
//
//    return arrayOfDoubleNumbers
//}
//
//let finalNumber = makeDoublefromInt(5,action:doubleFromInt)
//
//let finalDoubleNums = makeDoubleNumber(5,action:doubleTheNumber)
//
//print(arrayOfIntNumbers)
//print(finalNumber)
//print(finalDoubleNums)

//Exersice 2.9


//func makeCustomIterator(_ array:Array<Any>)->()->Any?{
//
//    var startingIndex = array.startIndex - 1
//
//    func passNextElement()->Any?{
//        startingIndex += 1
//        return array.indices.contains(startingIndex) ? array[startingIndex] : nil
//    }
//    return passNextElement
//}
//
//var array1 = [1,2,3,4]
//
//let x = makeCustomIterator(array1)
//let y = makeCustomIterator(array1)


//Exercise 2.10

//enum Day: Int {
//    case monday = 1
//    case tuesday
//    case wednesday
//    case thursday
//    case friday
//    case saturday
//    case sunday
//}
//
//let tuesday = Day(rawValue: 2)

//Exercise 2.11

//enum TimeUnit {
//
//    case Second
//    case Minute
//    case Hour
//    case Day
//    case Week
//    //TimeUnit.Day.convertTo(TimeUnit.Hour) == 24.0
//    func convertTo(_ to: TimeUnit) -> Any {
//
//        switch self{
//
//        case.Second :
//            if to == .Minute {
//                return 1
//            }else if to == .Hour{
//                return 3600.0
//            }else if to == .Day{
//                return 86400.0
//            }else if to == .Week{
//                return 86400.0 * 7.0
//            }
//
//        case .Minute :
//            if to == .Second {
//                return 60.0
//            }else if to == .Hour{
//                return 60.0
//            }else if to == .Day{
//                return 1440
//            }else if to == .Week{
//                return 10080.0
//            }
//
//        case .Hour :
//            if to == .Second {
//                return 3600.0
//            }else if to == .Minute{
//                return 60.0
//            }else if to == .Day{
//                return 24.0
//            }else if to == .Week{
//                return 24.0 * 7.0
//            }
//        case .Day :
//            if to == .Second {
//                return 86400.0
//            }else if to == .Minute{
//                return 1440.0
//            }else if to == .Hour{
//                return 24.0
//            }else if to == .Week{
//                return 7.0
//            }
//
//        case .Week :
//            if to == .Second {
//                return 604800.00
//            }else if to == .Minute{
//                return 10080.0
//            }else if to == .Hour{
//                return 24.0 * 7.0
//            }else if to == .Day{
//                return 7.0
//            }
//
//    }
//        return "Nothing to preview"
//    }
//}
//
//print(TimeUnit.Second.convertTo(.Day)

//Exercise 2.12

//enum handShape {
//
//    case paper
//    case scissors
//    case rock
//}
//
//enum matchResult {
//    case win
//    case draw
//    case lose
//}
//
//
//func match(_ hand_1:handShape,_ hand_2:handShape)->String{
//
//    if hand_1 == .paper && hand_2 == .paper {
//        return "The result is \(matchResult.draw)"
//    } else if hand_1 == .scissors && hand_2 == .scissors {
//        return "The result is \(matchResult.draw)"
//    } else if hand_1 == .rock && hand_2 == .rock {
//        return "The result is \(matchResult.draw)"
//    } else if hand_1 == .paper && hand_2 == .rock {
//        return "The result is \(matchResult.win) for the hand 1"
//    } else if hand_1 == .paper && hand_2 == .scissors {
//        return "The result is \(matchResult.win) for the hand 2"
//    } else if hand_1 == .scissors && hand_2 == .rock {
//        return "The result is \(matchResult.win) for the hand 2"
//    } else if hand_1 == .rock && hand_2 == .scissors {
//        return " The result is \(matchResult.win) for the hand 1"
//    } else if hand_1 == .rock && hand_2 == .paper {
//        return  "The result is \(matchResult.win) for the hand 2"
//    } else if hand_1 == .scissors && hand_2 == .paper {
//        return "The result is \(matchResult.win) for the hand 1"
//    } else {return "No more actions to preview"}
//
//}
//
//let result = match(.paper,.paper)

//Exercise 2.13

//enum Rank: Int {
//    case Ace = 1
//    case Two = 2
//    case Three = 3
//    case Four = 4
//    case Five = 5
//    case Six = 6
//    case Seven = 7
//    case Eight = 8
//    case Nine = 9
//    case Ten = 10
//    case Jack = 11
//    case Queen = 12
//    case King = 13
//
//
//}
//
//
//enum Suite : Int {
//case diamonds = 1
//case hearts = 2
//case spades = 3
//case clubs = 4
//}
//
//typealias Card = (Rank, Suite)
//
//
//func creationOfCard ()-> [Card]{
//
//    var cards = [Card]()
//
//    for i in 1...13{
//        for j in 1...4{
//            var card = (Rank(rawValue: i)!,Suite(rawValue: j)!)
//            cards.append(card)
//
//        }
//    }
//    return cards
//}
//
//let cards = creationOfCard()
//print("The cards are \n")
//for card in cards{
//    print(card.0,card.1)
//}
